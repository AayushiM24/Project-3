var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//creating the player Sofia
var Sofia = createSprite(20,25,10,10);
Sofia.shapeColor= "pink";

//creating the maze walls (wall1 - wall2)
  var wall1 = createSprite(110,45,20,90);
  wall1.shapeColor= "purple";
  var wall2 = createSprite(25,60,50,20);
  wall2.shapeColor= "purple";
  var wall3 = createSprite(70,140,140,20);
  wall3.shapeColor= "purple";
  var wall4 = createSprite(190,115,20,150);
  wall4.shapeColor="purple";
  var wall5 = createSprite(240,180,80,20);
  wall5.shapeColor= "purple";
  var wall6 = createSprite(240,60,20,120);
  wall6.shapeColor= "purple";
  var wall7 = createSprite(325,40,100,20);
  wall7.shapeColor= "purple";
  var wall8 = createSprite(330,140,20,180);
  wall8.shapeColor= "purple";
  var wall9 = createSprite(370,140,60,20);
  wall9.shapeColor= "purple";
  var wall10 = createSprite(370,220,60,20);
  wall10.shapeColor= "purple";
  var wall11 = createSprite(360,275,20,50);
  wall11.shapeColor= "purple";
  var wall12 = createSprite(360,295,80,20);
  wall12.shapeColor= "purple";
  var wall13 = createSprite(330,345,140,20);
  wall13.shapeColor= "purple";
  var wall14 = createSprite(290,260,20,100);
  wall14.shapeColor= "purple";
  var wall15 = createSprite(240,300,80,20);
  wall15.shapeColor= "purple";
  var wall16 = createSprite(130,260,20,160);
  wall16.shapeColor= "purple";
  var wall17 = createSprite(200,245,120,20);
  wall17.shapeColor="purple";
  var wall18 = createSprite(210,370,20,60);
  wall18.shapeColor = "purple";
  var wall19 = createSprite(60,270,20,180);
  wall19.shapeColor= "purple";
  var wall20 = createSprite(110,370,120,20);
  wall20.shapeColor= "purple";
  var wall21 = createSprite(15,240,30,20);
  wall21.shapeColor= "purple";
  var wall22 = createSprite(25,325,50,20);
  wall22.shapeColor= "purple";

//create cup
var cup = createSprite(390,380,20,50);
cup.shapeColor= "gold";

function draw() {
  background("lightblue");
  
  
createEdgeSprites();
Sofia.bounceOff(edges);

Sofia.bounceOff(wall1);
Sofia.bounceOff(wall2);
Sofia.bounceOff(wall3);
Sofia.bounceOff(wall4);
Sofia.bounceOff(wall5);
Sofia.bounceOff(wall6);
Sofia.bounceOff(wall7);
Sofia.bounceOff(wall8);
Sofia.bounceOff(wall9);
Sofia.bounceOff(wall10);
Sofia.bounceOff(wall11);
Sofia.bounceOff(wall12);
Sofia.bounceOff(wall13);
Sofia.bounceOff(wall14);
Sofia.bounceOff(wall15);
Sofia.bounceOff(wall16);
Sofia.bounceOff(wall17);
Sofia.bounceOff(wall18);
Sofia.bounceOff(wall19);
Sofia.bounceOff(wall20);
Sofia.bounceOff(wall21);
Sofia.bounceOff(wall22);
  

  
  if (keyDown(UP_ARROW)){
    Sofia.velocityX=0;
    Sofia.velocityY=-3;
  }
  
  if (keyDown(DOWN_ARROW)){
    Sofia.velocityX=0;
    Sofia.velocityY=3;
  }
  
  if (keyDown(LEFT_ARROW)){
    Sofia.velocityX=-3;
    Sofia.velocityY=0;
  }
  
  if (keyDown(RIGHT_ARROW)){
    Sofia.velocityX=3;
    Sofia.velocityY=0;
  }
  
  if (keyWentUp(UP_ARROW)){
    Sofia.velocityX=0;
    Sofia.velocityY=0;
  }
  
  if (keyWentUp(DOWN_ARROW)){
    Sofia.velocityX=0;
    Sofia.velocityY=0;
  }
  
  if (keyWentUp(LEFT_ARROW)){
    Sofia.velocityX=0;
    Sofia.velocityY=0;
  }
  
  if (keyWentUp(RIGHT_ARROW)){
    Sofia.velocityX=0;
    Sofia.velocityY=0;
  }
  
  if (Sofia.collide(cup)){
    background("white");
    checkwin();
    resetSofia();
  }
  
drawSprites();

}

function resetSofia()
{
  Sofia.x = 20;
  Sofia.y = 25;
}

function checkwin()
{
  
  textSize(40);
  stroke("red");
  text("You Win", 200,240);
  
}























// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
